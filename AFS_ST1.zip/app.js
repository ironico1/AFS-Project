const express=require('express');
const nodemailer=require('nodemailer');
const app=express();
require('dotenv').config();

app.set('view engine','hbs');
app.use(express.json());   ///json mai cobvert krke rq .body mai daal dega

app.use(express.urlencoded({extended:true})); 

let otp;
function generateOtp(){
    otpVal = Math.floor(1000 + Math.random() * 9000);
    return otpVal;
}

app.get('/', (req, res)=> {
    res.render('index');
});

app.post('/send',async(req,res)=>{
    // app pass is used to bypass th two factor authen of otp sent ..sirf user pass se dekr hm 1way authen kr rhe h ..2way krne ke liye app pass is used
    otp=generateOtp();
    const recemail=req.body.email;
    const transporter=nodemailer.createTransport({  //send mail function hota hai
        service:"gmail",
        auth:{
            user: "terastupid07@gmail.com",
            // environment var. are used so that we don't have to write and show our pass here ..and then agr new file me bana kr daal de pass but agr usse github pr daale to vo file bhi daalni pdegi so we created app pass bcz here app is trying to login not the user
            pass:process.env.PASS, 
        }
    })
    const mail={
        to: recemail,
        from: "terastupid07@gmail.com",
        subject:"otp",
        text: `${otp}`,
    }

    try{
        await transporter.sendMail(mail);
        res.send("otp sent successfully");
    }
    catch(err){
        res.send("OOPS! otp not sent");
    }
});

app.post('/verify',(req, res)=> {
    if (req.body.otp == otp) {
        res.send("You entered correct otp)");
    }
    else {
        res.send('otp is incorrect');
    }
});

app.listen(3000,()=>{
    console.log("http://localhost:3000");
})